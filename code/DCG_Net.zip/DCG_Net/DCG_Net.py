import math
import torch
import torch.nn.functional as F
from torch import nn
from torch_geometric.nn import knn_graph
from torch_geometric.utils import dense_to_sparse

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")


class SE_Block(nn.Module):
    def __init__(self, ch_in, reduction=8):
        super(SE_Block, self).__init__()
        self.avg_pool = nn.AdaptiveAvgPool2d(1)  # 全局自适应池化
        self.fc = nn.Sequential(
            nn.Linear(ch_in, ch_in // reduction, bias=False),
            nn.ReLU(inplace=True),
            nn.Linear(ch_in // reduction, ch_in, bias=False),
            nn.Sigmoid()
        )

    def forward(self, x):
        b, c, h, w = x.size()
        y = self.avg_pool(x).view(b, c)  # squeeze操作
        y = self.fc(y).view(b, c, 1, 1)  # FC获取通道注意力权重，是具有全局信息的
        return x * y.expand_as(x)  # 注意力作用每一个通道上


class CCM(nn.Module):
    def __init__(self, in_channel, out_channel, kernel_size=3):
        super(CCM, self).__init__()
        self.BN = nn.BatchNorm2d(in_channel)
        self.point_conv = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=1, stride=1,
                                    padding=0, groups=1)
        self.Activition_1 = nn.LeakyReLU(inplace=True)
        self.depth_conv = nn.Conv2d(in_channels=out_channel, out_channels=out_channel, kernel_size=kernel_size,
                                    stride=1,
                                    padding=kernel_size // 2, groups=out_channel)
        self.Activition_2 = nn.LeakyReLU(inplace=True)

    def forward(self, input):
        input = self.BN(input)
        out = self.point_conv(input)
        out = self.Activition_1(out)
        out = self.depth_conv(out)
        out = self.Activition_2(out)
        return out

class GCN(nn.Module):
    def __init__(self, input_dim: int, output_dim: int, position: torch.Tensor, neighbors: int):
        super(GCN, self).__init__()
        self.BN = nn.BatchNorm1d(input_dim)
        self.Activition_1 = nn.LeakyReLU(inplace=True)

        self.GCN_liner_out_1 = nn.Linear(input_dim, output_dim)
        self.GCN_liner_theta_1 = nn.Linear(input_dim, 128)  # 映射128维学习权重

        self.position = position
        self.neighbors = neighbors

        if self.neighbors > 0:
            self.neighbors = self.neighbors + 1
            self.col, self.row = self.edge_index = knn_graph(self.position, self.neighbors, batch=None, loop=True)
        if neighbors > 0: self.Spatial_Distance = torch.square(
            torch.norm(self.position[self.col] - self.position[self.row], dim=-1))

    def forward(self, H):
        H = self.BN(H)
        node_count = H.shape[0]
        H_1 = self.GCN_liner_theta_1(H)
        out = self.GCN_liner_out_1(H)

        if self.neighbors > 0:
            col, row = self.col, self.row
            A = torch.sigmoid(torch.multiply(H_1[col], H_1[row]).sum(-1))
            A = A.reshape([node_count, self.neighbors, -1])
            A = torch.softmax(A, dim=1)
            out = out[col].reshape([node_count, self.neighbors, -1])
            out = self.Activition_1(torch.multiply(A, out).sum(1))
        return out


class GCN_KNN(nn.Module):
    def __init__(self, height: int, width: int, channel: int, layer_per_channel: int, class_count: int,
                 hierarchy_matrices, adjacency_matrices,
                 neighbors):
        super(GCN_KNN, self).__init__()

        self.height = height
        self.width = width
        self.S_list = hierarchy_matrices
        self.A_list = adjacency_matrices
        self.neighbors = neighbors
        self.S_list_Hat_T = []

        for i in range(len(hierarchy_matrices)):
            temp = hierarchy_matrices[i]
            self.S_list_Hat_T.append((temp / (torch.sum(temp, 0, keepdim=True, dtype=torch.float32))).t())

        positions = self.getPositions()
        self.positions = []
        for i in range(len(hierarchy_matrices)):
            positions = torch.mm(self.S_list_Hat_T[i], positions)
            self.positions.append(positions)

        layer_channels = layer_per_channel
        layer_per_depeh = [layer_channels]
        for i in range(len(hierarchy_matrices)):
            layer_channels = layer_channels // 2
            layer_per_depeh.append(layer_channels)

        self.GCN_layers = GCN(layer_per_depeh[0], layer_per_depeh[0],self.positions[0],
                              self.neighbors)
        if len(layer_per_depeh) <= 1: layer_per_depeh.append(layer_channels)

    def getPositions(self):
        # KNN
        x = torch.arange(0, self.height)
        y = torch.arange(0, self.width)
        x, y = torch.meshgrid([x, y])
        xy = torch.stack([x, y], -1).reshape([self.height * self.width, 2]).float()
        return xy.to(device=device)

    def forward(self, H_i):

        H_i = torch.mm(self.S_list_Hat_T[0], H_i)
        H_i = self.GCN_layers(H_i)
        H_i = torch.mm(self.S_list[0], H_i)

        return H_i


class net_up(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(net_up, self).__init__()

        self.BN = nn.BatchNorm2d(in_channel)
        self.up = nn.ConvTranspose2d(in_channel, in_channel, kernel_size=2, stride=2)
        self.convd_up = CCM(in_channel, out_channel)

    def forward(self, input_1):
        input_1 = self.up(input_1)
        return self.convd_up(input_1)


class net_down(nn.Module):
    def __init__(self, in_channel, out_channel):
        super(net_down, self).__init__()

        self.pool = nn.MaxPool2d(2, padding=1)
        self.convd_dowm = CCM(in_channel, out_channel, kernel_size=5)
        self.conv = nn.Conv2d(in_channels=in_channel, out_channels=out_channel, kernel_size=1, stride=1,
                              padding=0, groups=1)
        self.seblock = SE_Block(in_channel)

    def forward(self, input_1, input_2, flag):
        input_1 = self.pool(input_1)
        _, _, h, w = input_1.shape
        input_1 = input_1[:, :, :h - 1, :w - 1]
        if flag == 1:
            x = torch.cat([input_1, input_2], dim=1)
        else:
            x = torch.cat([input_1, input_2], dim=1)
            x = self.seblock(x)
        output = self.convd_dowm(x)
        return output


class DCG_Net(nn.Module):
    def __init__(self, height: int, width: int, bands: int, class_count, S_list_input, A_list_input,
                 neighbors):
        super(DCG_Net, self).__init__()

        self.height = height
        self.width = width
        self.class_count = class_count
        self.bands = bands
        self.S_list = S_list_input
        self.A_list = A_list_input
        self.neighbors = neighbors
        self.layer_count = len(S_list_input)

        layer_channels = 128
        layer_per_depth = [layer_channels]
        for i in range(len(S_list_input)):
            layer_channels = layer_channels * 2
            layer_per_depth.append(layer_channels)

        S_array1 = S_list_input[0]
        S_array2 = S_list_input[2]

        A_array1 = A_list_input[0]
        A_array2 = A_list_input[2]

        self.CNN_mid_in_layer = CCM(self.bands, layer_per_depth[0], kernel_size=5)
        self.CNN_up_layer_1 = net_up(layer_per_depth[0], layer_per_depth[1])

        self.GCN_KNN_Per_1 = GCN_KNN(self.height, self.width, bands, layer_per_depth[0], class_count, S_array1,
                                 A_array1, self.neighbors)

        self.GCN_KNN_Per_2 = GCN_KNN(self.height * 2, self.width * 2, bands, layer_per_depth[1], class_count, S_array2,
                                 A_array2, self.neighbors)

        self.CNN_mid_out_layer = CCM(layer_per_depth[0], layer_per_depth[0], kernel_size=5)
        self.CNN_down_layer_1 = CCM(layer_per_depth[1], layer_per_depth[1] // 2, kernel_size=5)

        self.CNN_up_cat_layer = net_down(layer_per_depth[1], layer_per_depth[0])
        self.seblock = SE_Block(layer_per_depth[0])

        self.Softmax = nn.Sequential(nn.Linear(128, self.class_count), nn.Softmax(-1))

    def forward(self, input: torch.Tensor):
        (h, w, c) = input.shape
        _2h = h * 2
        _2w = w * 2
        x = torch.unsqueeze(input.permute([2, 0, 1]), 0)

        H_0 = self.CNN_mid_in_layer(x)
        H_1 = self.CNN_up_layer_1(H_0)

        H_0 = torch.squeeze(H_0, 0).permute([1, 2, 0])
        H_i_0 = H_0.reshape([h * w, -1])

        H_1 = torch.squeeze(H_1, 0).permute([1, 2, 0])
        H_i_1 = H_1.reshape([_2h * _2w, -1])

        H_i_0_out = self.GCN_KNN_Per_1(H_i_0)
        H_i_0_out = H_i_0_out.reshape([1, h, w, -1]).permute([0, 3, 1, 2])

        H_i_1_out = self.GCN_KNN_Per_2(H_i_1)
        H_i_1_out = H_i_1_out.reshape([1, _2h, _2w, -1]).permute([0, 3, 1, 2])

        H_i_0_out = self.CNN_mid_out_layer(H_i_0_out)
        H_i_1_out = self.CNN_down_layer_1(H_i_1_out)

        final_features = self.CNN_up_cat_layer(H_i_1_out, H_i_0_out, 0)
        final_features = torch.squeeze(final_features, 0).permute([1, 2, 0]).reshape([h * w, -1])
        Y = self.Softmax(final_features)
        return Y


