import numpy as np
import scipy.io as sio
import torch

device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

class SegmentMap(object):
    def __init__(self, datasetname: np.array):

        if datasetname == 'indian_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapsindian.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1indian.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2indian.mat')
            self.seg_2 = segs_2['segmentmaps_2']

        if datasetname == 'simu_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapssimu.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1simu.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2simu.mat')
            self.seg_2 = segs_2['segmentmaps_2']

        if datasetname == 'paviaU_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapspaviau.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1paviau.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2paviau.mat')
            self.seg_2 = segs_2['segmentmaps_2']

        if datasetname == 'paviaUcropped_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapspu_cropped.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1pu_cropped.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2pu_cropped.mat')
            self.seg_2 = segs_2['segmentmaps_2']

        if datasetname == 'salinas_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapssalinas.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1salinas.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2salinas.mat')
            self.seg_2 = segs_2['segmentmaps_2']

        if datasetname == 'KSC_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapsksc.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1ksc.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2ksc.mat')
            self.seg_2 = segs_2['segmentmaps_2']
        if datasetname == 'Botswana_':
            segs = sio.loadmat('Data/Superpixel_segments/segmentmapsbots.mat')
            self.segs = segs['segmentmaps']
            segs_1 = sio.loadmat('Data/Superpixel_segments/segmentmaps_1bots.mat')
            self.seg_1 = segs_1['segmentmaps_1']
            segs_2 = sio.loadmat('Data/Superpixel_segments/segmentmaps_2bots.mat')
            self.seg_2 = segs_2['segmentmaps_2']

    def getHierarchy(self):
        all_S_list_gpu = []  # 创建一个用于存储所有S_list_gpu的列表
        all_A_list_gpu = []

        segs = self.segs
        layers, h, w = self.segs.shape
        print(layers)
        segs = np.concatenate([np.reshape([i for i in range(h * w)], [1, h, w]), segs], axis=0)
        layers = layers + 1
        S_list = []
        for i in range(layers - 1):
            S = np.zeros([np.max(segs[i]) + 1, np.max(segs[i + 1]) + 1], dtype=np.bool_)
            l1 = np.reshape(segs[i], [-1])
            l2 = np.reshape(segs[i + 1], [-1])
            for x in range(h * w):
                if S[l1[x], l2[x]] != 1: S[l1[x], l2[x]] = 1
            S_list.append(S)

        # 计算S_list的大小
        memory_size_bytes = 0
        for S_matrix in S_list:
            memory_size_bytes += S_matrix.nbytes
        # 转换为千字节（1 KB = 1024 字节）
        memory_size_kb = memory_size_bytes / 1024
        # 转换为兆字节（1 MB = 1024 KB）
        memory_size_mb = memory_size_kb / 1024
        print(f"S_list 中所有矩阵的总内存大小：{memory_size_bytes} 字节，{memory_size_kb:.2f} KB，{memory_size_mb:.2f} MB")

        A_list = []
        superpixelLabels = self.segs
        for l in range(len(superpixelLabels)):
            segments = np.reshape(superpixelLabels[l], [h, w])
            superpixel_count = int(np.max(superpixelLabels[l])) + 1
            A = np.zeros([superpixel_count, superpixel_count], dtype=np.float32)
            for i in range(h - 1):
                for j in range(w - 1):
                    sub = segments[i:i + 2, j:j + 2]
                    sub_max = np.max(sub).astype(np.int32)
                    sub_min = np.min(sub).astype(np.int32)
                    if sub_max != sub_min:
                        idx1 = sub_max
                        idx2 = sub_min
                        if A[idx1, idx2] != 0: continue
                        A[idx1, idx2] = A[idx2, idx1] = 1
            A_list.append(A)

        S_list_gpu = []
        A_list_gpu = []
        for k in range(len(S_list)):
            S_list_gpu.append(torch.from_numpy(np.array(S_list[k], dtype=np.float32)).to(device))
            A_list_gpu.append(torch.from_numpy(np.array(A_list[k], dtype=np.float32)).to(device))

        all_S_list_gpu.append(S_list_gpu)
        all_A_list_gpu.append(A_list_gpu)

        segs_1 = self.seg_1
        layers_1, h_1, w_1 = segs_1.shape
        segs = np.concatenate([np.reshape([i for i in range(h_1 * w_1)], [1, h_1, w_1]), segs_1], axis=0)
        layers = layers_1 + 1
        S_list_1 = []
        for i in range(layers - 1):
            S = np.zeros([np.max(segs[i]) + 1, np.max(segs[i + 1]) + 1], dtype=np.bool_)
            l1 = np.reshape(segs[i], [-1])
            l2 = np.reshape(segs[i + 1], [-1])
            for x in range(h_1 * w_1):
                if S[l1[x], l2[x]] != 1: S[l1[x], l2[x]] = 1
            S_list_1.append(S)

        # 计算S_list_2的大小
        memory_size_bytes = 0
        for S_matrix_1 in S_list_1:
            memory_size_bytes += S_matrix_1.nbytes
        # 转换为千字节（1 KB = 1024 字节）
        memory_size_kb = memory_size_bytes / 1024
        # 转换为兆字节（1 MB = 1024 KB）
        memory_size_mb = memory_size_kb / 1024
        print(
            f"S_list_1 中所有矩阵的总内存大小：{memory_size_bytes} 字节，{memory_size_kb:.2f} KB，{memory_size_mb:.2f} MB")

        A_list_1 = []
        superpixelLabels = self.seg_1
        for l in range(len(superpixelLabels)):
            segments = np.reshape(superpixelLabels[l], [h_1, w_1])
            superpixel_count = int(np.max(superpixelLabels[l])) + 1
            A = np.zeros([superpixel_count, superpixel_count], dtype=np.float32)
            # (h_1, w_1) = (h_1, w_1)
            for i in range(h_1 - 1):
                for j in range(w_1 - 1):
                    sub = segments[i:i + 2, j:j + 2]
                    sub_max = np.max(sub).astype(np.int32)
                    sub_min = np.min(sub).astype(np.int32)
                    if sub_max != sub_min:
                        idx1 = sub_max
                        idx2 = sub_min
                        if A[idx1, idx2] != 0: continue
                        A[idx1, idx2] = A[idx2, idx1] = 1
            A_list_1.append(A)

        S_list_gpu_1 = []
        A_list_gpu_1 = []
        for k in range(len(S_list)):
            S_list_gpu_1.append(torch.from_numpy(np.array(S_list_1[k], dtype=np.float32)).to(device))
            A_list_gpu_1.append(torch.from_numpy(np.array(A_list_1[k], dtype=np.float32)).to(device))
        all_S_list_gpu.append(S_list_gpu_1)
        all_A_list_gpu.append(A_list_gpu_1)

        segs_2 = self.seg_2
        layers_2, h_2, w_2 = segs_2.shape
        segs = np.concatenate([np.reshape([i for i in range(h_2 * w_2)], [1, h_2, w_2]), segs_2], axis=0)
        layers = layers_2 + 1
        S_list_2 = []
        for i in range(layers - 1):
            S = np.zeros([np.max(segs[i]) + 1, np.max(segs[i + 1]) + 1], dtype=np.bool_)
            l1 = np.reshape(segs[i], [-1])
            l2 = np.reshape(segs[i + 1], [-1])
            for x in range(h_2 * w_2):
                if S[l1[x], l2[x]] != 1: S[l1[x], l2[x]] = 1
            S_list_2.append(S)

        # 计算S_list_2的大小
        memory_size_bytes = 0
        for S_matrix_2 in S_list_2:
            memory_size_bytes += S_matrix_2.nbytes
        # 转换为千字节（1 KB = 1024 字节）
        memory_size_kb = memory_size_bytes / 1024
        # 转换为兆字节（1 MB = 1024 KB）
        memory_size_mb = memory_size_kb / 1024
        print(
            f"S_list_2 中所有矩阵的总内存大小：{memory_size_bytes} 字节，{memory_size_kb:.2f} KB，{memory_size_mb:.2f} MB")

        A_list_2 = []
        superpixelLabels = self.seg_2
        for l in range(len(superpixelLabels)):
            segments = np.reshape(superpixelLabels[l], [h_2, w_2])
            superpixel_count = int(np.max(superpixelLabels[l])) + 1
            A = np.zeros([superpixel_count, superpixel_count], dtype=np.float32)
            # (h_2, w_2) = (h_2, w_2)
            for i in range(h_2 - 1):
                for j in range(w_2 - 1):
                    sub = segments[i:i + 2, j:j + 2]
                    sub_max = np.max(sub).astype(np.int32)
                    sub_min = np.min(sub).astype(np.int32)
                    if sub_max != sub_min:
                        idx1 = sub_max
                        idx2 = sub_min
                        if A[idx1, idx2] != 0: continue
                        A[idx1, idx2] = A[idx2, idx1] = 1
            A_list_2.append(A)

        S_list_gpu_2 = []
        A_list_gpu_2 = []
        for k in range(len(S_list)):
            S_list_gpu_2.append(torch.from_numpy(np.array(S_list_2[k], dtype=np.float32)).to(device))
            A_list_gpu_2.append(torch.from_numpy(np.array(A_list_2[k], dtype=np.float32)).to(device))
        all_S_list_gpu.append(S_list_gpu_2)
        all_A_list_gpu.append(A_list_gpu_2)

        return S_list, A_list, S_list_2, A_list_2, all_S_list_gpu, all_A_list_gpu




