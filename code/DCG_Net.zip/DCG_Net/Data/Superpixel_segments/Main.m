clear; close all;

FLAG=4;
switch(FLAG)
    case 1
        hsi=load('D:\Pycharm\Pytorch_pro\zwk_work\2024.5.16\MSSG_UNet_work\Data\indian\Indian_pines_corrected.mat');hsi=hsi.indian_pines_corrected;
        n_superpixels=[512];
        n_superpixels_1=[512];
        n_superpixels_2=[512];
    case 2
        hsi=load('/home/pc/zhuwenkai/MSSG_UNet_work/Data/PaviaU/PaviaU.mat');hsi=hsi.paviaU;
        n_superpixels=[512];
        n_superpixels_1=[1024];
        n_superpixels_2=[512];
    case 3
        hsi=load('D:\Pycharm\Pytorch_pro\zwk_work\2024.5.16\MSSG_UNet_work\Data\Salinas\Salinas_corrected.mat');hsi=hsi.salinas_corrected;
        n_superpixels=[512];
        n_superpixels_1=[64];
        n_superpixels_2=[512];
    case 4
        hsi=load('D:\Pycharm\Pytorch_pro\zwk_work\2024.5.16\MSSG_UNet_work\Data\KSC\KSC.mat');hsi=hsi.KSC;
        n_superpixels=[512];
        n_superpixels_1=[64];
        n_superpixels_2=[512];
    case 5
        hsi=load('D:\Pycharm\Pytorch_pro\MSSG_UNet_work\Data\data\Pavia_university_cropped.mat');hsi=hsi.pavia_university_cropped;
        n_superpixels=[1024];
        n_superpixels_1=[1024];
        n_superpixels_2=[512];
    case 6
        hsi=load('D:\Pycharm\Pytorch_pro\MSSG_UNet_work\Data\Simu\Simu_data.mat');hsi=hsi.Simu_data;
        n_superpixels=[1024];
        n_superpixels_1=[1024];
        n_superpixels_2=[512];
    case 7
        hsi=load('home/pc/zhuwenkai/MSSG_UNet_work/Data/Botswana/Botswana.mat');hsi=hsi.Botswana;
        n_superpixels=[512];
        n_superpixels_1=[512];
        n_superpixels_2=[512];
%     case 5
%         hsi=load('..\..\HyperImage_data\Houston2013\Houston.mat');hsi=hsi.Houston;
%         n_superpixels=[2048,1024,512,256];
%     case 6
%         hsi=load('..\..\HyperImage_data\HyRANK\Loukia.mat');hsi=hsi.Loukia;
%         n_superpixels=[2048,1024,512,256];
%     case 7
%         hsi=load('..\..\HyperImage_data\Botswana\Botswana.mat');hsi=hsi.Botswana;
%         n_superpixels=[2048,1024,512,256];
%     case 8
%         hsi=load('..\..\HyperImage_data\Houston2018\HoustonU.mat');hsi=hsi.houstonU;
%         n_superpixels=[2048,1024,512,256];
%         hsi=hsi(:,1:400,:);%
%     case 9
%         hsi=load('..\..\HyperImage_data\xuzhou\xuzhou.mat');hsi=hsi.xuzhou;
%         n_superpixels=[2048,1024,512,256];
%     case 10
%         hsi=load('..\..\HyperImage_data\WDC\WDC.mat');hsi=hsi.wdc;
%         n_superpixels=[2048,1024,512,256];
end

%%
% 高和宽扩大两倍
upsampled_hsi_2 = imresize(hsi, 2);
upsampled_hsi_2=double(upsampled_hsi_2);
[h_2,w_2,c_2]=size(upsampled_hsi_2);
upsampled_hsi_2=mapminmax( reshape(upsampled_hsi_2,[h_2*w_2,c_2])');
upsampled_hsi_2=reshape(upsampled_hsi_2',[h_2,w_2,c_2]);
upsampled_hsi_2 = imfilter(upsampled_hsi_2, fspecial('gaussian',[3,3]), 'replicate');
upsampled_hsi_2=reshape(upsampled_hsi_2,[h_2*w_2,c_2])';
pcacomps=pca(upsampled_hsi_2);
I_2=pcacomps(:,[3,2,1])';
I_2=(mapminmax(I_2)+1)/2*255;
I_2=reshape(uint8(I_2)',[h_2,w_2,3]);
for i=1:3
    I_2(:,:,i)=imadjust(histeq(I_2(:,:,i))); %%
end
I_2 = imfilter(I_2, fspecial('unsharp',0.05), 'replicate');
E_2=uint8(zeros([h_2,w_2]));

tic; sh=SuperpixelHierarchyMex(I_2,E_2,0.0,0.1); toc
segmentmaps_2=zeros(size(n_superpixels_2,2),h_2,w_2);

for i=1:size(n_superpixels_2,2)
    GetSuperpixels(sh,n_superpixels_2(:,i));
    segmentmaps_2(i,:,:)=sh.label;
end

switch(FLAG)
    case 1
        save segmentmaps_2indian.mat segmentmaps_2
    case 2
        save segmentmaps_2paviau.mat segmentmaps_2
    case 3
        save segmentmaps_2salinas.mat segmentmaps_2
    case 4
        save segmentmaps_2ksc.mat segmentmaps_2
    case 5
        save segmentmaps_2pu_cropped.mat segmentmaps_2
    case 6
        save segmentmaps_2simu.mat segmentmaps_2
    case 7
        save segmentmaps_2bots.mat segmentmaps_2
%     case 5
%         save segmentmapshst.mat segmentmaps_2
%     case 6
%         save segmentmapsloukia.mat segmentmaps_2
%     case 7
%         save segmentmapsbot.mat segmentmaps_2
%     case 8
%         save segmentmapshstu.mat segmentmaps_2
%     case 9
%         save segmentmapsxuzhou.mat segmentmaps_2
%     case 10
%         save segmentmapswdc.mat segmentmaps_2
end


%%
%高和宽缩小两倍
downsampled_hsi = imresize(hsi, 0.5,'bicubic');
downsampled_hsi=double(downsampled_hsi);
[h_1,w_1,c_1]=size(downsampled_hsi);
downsampled_hsi=mapminmax( reshape(downsampled_hsi,[h_1*w_1,c_1])');
downsampled_hsi=reshape(downsampled_hsi',[h_1,w_1,c_1]);
downsampled_hsi = imfilter(downsampled_hsi, fspecial('gaussian',[3,3]), 'replicate');
downsampled_hsi=reshape(downsampled_hsi,[h_1*w_1,c_1])';
pcacomps=pca(downsampled_hsi);
I_1=pcacomps(:,[3,2,1])';
I_1=(mapminmax(I_1)+1)/2*255;
I_1=reshape(uint8(I_1)',[h_1,w_1,3]);
for i=1:3
    I_1(:,:,i)=imadjust(histeq(I_1(:,:,i))); %%
end
I_1 = imfilter(I_1, fspecial('unsharp',0.05), 'replicate');
E_1=uint8(zeros([h_1,w_1]));

% fine detail structure
tic; sh=SuperpixelHierarchyMex(I_1,E_1,0.0,0.1); toc
segmentmaps_1=zeros(size(n_superpixels_1,2),h_1,w_1);
for i=1:size(n_superpixels_1,2)
    GetSuperpixels(sh,n_superpixels_1(:,i));
    segmentmaps_1(i,:,:)=sh.label;
end

switch(FLAG)
    case 1
        save segmentmaps_1indian.mat segmentmaps_1
    case 2
        save segmentmaps_1paviau.mat segmentmaps_1
    case 3
        save segmentmaps_1salinas.mat segmentmaps_1
    case 4
        save segmentmaps_1ksc.mat segmentmaps_1
    case 5
        save segmentmaps_1pu_cropped.mat segmentmaps_1 
    case 6
        save segmentmaps_1simu.mat segmentmaps_1 
    case 7
        save segmentmaps_1bots.mat segmentmaps_1
%     case 5
%         save segmentmapshst.mat segmentmaps_1
%     case 6
%         save segmentmapsloukia.mat segmentmaps_1
%     case 7
%         save segmentmapsbot.mat segmentmaps_1
%     case 8
%         save segmentmapshstu.mat segmentmaps_1
%     case 9
%         save segmentmapsxuzhou.mat segmentmaps_1
%     case 10
%         save segmentmapswdc.mat segmentmaps_1
end


%%
%高和宽不变
hsi=double(hsi);
[h,w,c]=size(hsi);
hsi=mapminmax( reshape(hsi,[h*w,c])');
hsi=reshape(hsi',[h,w,c]);
hsi = imfilter(hsi, fspecial('gaussian',[3,3]), 'replicate');
hsi=reshape(hsi,[h*w,c])';
pcacomps=pca(hsi);
I=pcacomps(:,[3,2,1])';
I=(mapminmax(I)+1)/2*255;
I=reshape(uint8(I)',[h,w,3]);
for i=1:3
    I(:,:,i)=imadjust(histeq(I(:,:,i))); %%
end
I = imfilter(I, fspecial('unsharp',0.05), 'replicate');
E=uint8(zeros([h,w]));

% fine detail structure
tic; sh=SuperpixelHierarchyMex(I,E,0.0,0.1); toc
segmentmaps=zeros(size(n_superpixels,2),h,w);
for i=1:size(n_superpixels,2)
    GetSuperpixels(sh,n_superpixels(:,i));
    segmentmaps(i,:,:)=sh.label;
end

switch(FLAG)
    case 1
        save segmentmapsindian.mat segmentmaps
    case 2
        save segmentmapspaviau.mat segmentmaps
    case 3
        save segmentmapssalinas.mat segmentmaps
    case 4
        save segmentmapsksc.mat segmentmaps
    case 5
        save segmentmapspu_cropped.mat segmentmaps
    case 6
        save segmentmapssimu.mat segmentmaps
    case 7
        save segmentmapsbots.mat segmentmaps
%     case 5
%         save segmentmapshst.mat segmentmaps
%     case 6
%         save segmentmapsloukia.mat segmentmaps
%     case 7
%         save segmentmapsbot.mat segmentmaps
%     case 8
%         save segmentmapshstu.mat segmentmaps
%     case 9
%         save segmentmapsxuzhou.mat segmentmaps
%     case 10
%         save segmentmapswdc.mat segmentmaps
end

% % get whatever you want
% GetSuperpixels(sh,n_superpixels_2(1)); color1 = MeanColor(double(I),sh.label);
% % GetSuperpixels(sh,n_superpixels(2)); color2 = MeanColor(double(I),sh.label);
% % GetSuperpixels(sh,n_superpixels(3)); color3= MeanColor(double(I),sh.label);
% % GetSuperpixels(sh,n_superpixels(4)); color4= MeanColor(double(I),sh.label);
% figure,imshow([color1]); %,color2; color3,color4



