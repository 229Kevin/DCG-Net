import scipy.io as sio

import get_classification_map

def load_dataset(Dataset):
    if Dataset == 'IN':
        mat_data = sio.loadmat('Data/indian/Indian_pines_corrected.mat')  # 图像数据
        mat_gt = sio.loadmat('Data/indian/Indian_pines_gt.mat')  # 标签数据
        data_hsi = mat_data['indian_pines_corrected']
        gt_hsi = mat_gt['indian_pines_gt']

    if Dataset == 'UP':
        uPavia = sio.loadmat('Data/PaviaU/PaviaU.mat')
        gt_uPavia = sio.loadmat('Data/PaviaU/PaviaU_gt.mat')
        data_hsi = uPavia['paviaU']
        gt_hsi = gt_uPavia['paviaU_gt']

        # uPavia = sio.loadmat('Data/Pavia_university_cropped/Pavia_university_cropped.mat')
        # gt_uPavia = sio.loadmat('Data/Pavia_university_cropped/Pavia_university_gt.mat')
        # data_hsi = uPavia['pavia_university_cropped']
        # gt_hsi = gt_uPavia['pavia_university_gt']

    if Dataset == 'SI':
        mat_data = sio.loadmat('Data/Simu/Simu_data.mat')  # 图像数据
        mat_gt = sio.loadmat('Data/Simu/Simu_label.mat')  # 标签数据
        data_hsi = mat_data['Simu_data']
        gt_hsi = mat_gt['Simu_label']

    if Dataset == 'PC':
        uPavia = sio.loadmat('Data/Pavia.mat')
        gt_uPavia = sio.loadmat('Data/Pavia_gt.mat')
        data_hsi = uPavia['pavia']
        gt_hsi = gt_uPavia['pavia_gt']

    if Dataset == 'SA':
        SV = sio.loadmat('Data/Salinas/Salinas_corrected.mat')
        gt_SV = sio.loadmat('Data/Salinas/Salinas_gt.mat')
        data_hsi = SV['salinas_corrected']
        gt_hsi = gt_SV['salinas_gt']

    if Dataset == 'KSC':
        KSC = sio.loadmat('Data/KSC/KSC.mat')
        gt_KSC = sio.loadmat('Data/KSC/KSC_gt.mat')
        data_hsi = KSC['KSC']
        gt_hsi = gt_KSC['KSC_gt']

    if Dataset == 'BS':
        BS = sio.loadmat('Data/Botswana/Botswana.mat')
        gt_BS = sio.loadmat('Data/Botswana/Botswana_gt.mat')
        data_hsi = BS['Botswana']
        gt_hsi = gt_BS['Botswana_gt']

    if Dataset == 'HT':
        HS = sio.loadmat('Data/houston.mat')
        gt_HS = sio.loadmat('Data/houston_gt_sum.mat')
        data_hsi = HS['hsi']
        gt_hsi = gt_HS['houston_gt_sum']

    if Dataset == 'LK':
        LK = sio.loadmat('Data/WHU_Hi_LongKou.mat')
        gt_LK = sio.loadmat('Data/WHU_Hi_LongKou_gt.mat')
        data_hsi = LK['WHU_Hi_LongKou']
        gt_hsi = gt_LK['WHU_Hi_LongKou_gt']

    if Dataset == 'HH':
        HH = sio.loadmat('Data/WHU_Hi_HongHu.mat')
        gt_HH = sio.loadmat('Data/WHU_Hi_HongHu_gt.mat')
        data_hsi = HH['WHU_Hi_HongHu']
        gt_hsi = gt_HH['WHU_Hi_HongHu_gt']

    if Dataset == 'HC':
        HC = sio.loadmat('Data/WHU_Hi_HanChuan.mat')
        gt_HC = sio.loadmat('Data/WHU_Hi_HanChuan_gt.mat')
        data_hsi = HC['WHU_Hi_HanChuan']
        gt_hsi = gt_HC['WHU_Hi_HanChuan_gt']

    return data_hsi, gt_hsi


if __name__ == '__main__':
    data, gt = load_dataset('BS')
    get_classification_map.Draw_Classification_Map(gt, "results\\" + "BS" + "_gt")

